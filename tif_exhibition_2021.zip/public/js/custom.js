$(document).ready(function(){

    $('.select2').select2({
        theme: 'bootstrap4',
    });
    
    $('.select2nosearch').select2({
        theme: 'bootstrap4',
        minimumResultsForSearch: -1,
    });

    // $('.venobox').venobox({
    //     frameheight: '90vh',
    // });
    
});