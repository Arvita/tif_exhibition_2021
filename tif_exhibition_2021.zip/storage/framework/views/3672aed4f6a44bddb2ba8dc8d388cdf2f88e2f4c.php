<?php $__env->startSection('content'); ?>
<section class="content col">
    <form action="<?php echo e(route('user.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

    <div class="card">
        <div class="card-header">
            <h3 class="card-title"><?php echo e($data['title']); ?></h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
            </div>
        </div>
        <div class="card-body">
            <div class="form-group row">
                <label for="name" class="col-sm-2 control-label">Nama Lengkap</label>
                <div class="col-sm-10">
                    <input type="text" id="name" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" placeholder="Nama Lengkap" value="<?php echo e(old('name')); ?>">
                    <?php if($errors->has('name')): ?>
                        <span class="invalid-feedback">
                            <p><?php echo e($errors->first('name')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="email" class="col-sm-2 control-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" id="email" name="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="Email" value="<?php echo e(old('email')); ?>">
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback">
                            <p><?php echo e($errors->first('email')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="username" class="col-sm-2 control-label">Username</label>
                <div class="col-sm-10">
                    <input type="username" id="username" name="username" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" placeholder="Username" value="<?php echo e(old('username')); ?>">
                    <?php if($errors->has('username')): ?>
                        <span class="invalid-feedback">
                            <p><?php echo e($errors->first('username')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="role" class="col-sm-2 control-label">User Role</label>
                <div class="col-sm-10">
                    <select name="role" id="role" class="form-control select2nosearch<?php echo e($errors->has('role') ? ' is-invalid' : ''); ?>" style="width: 100%;">
                        <option value="1">Officer</option>
                        <option value="0">Admin</option>
                    </select>
                    <?php if($errors->has('role')): ?>
                        <span class="invalid-feedback">
                            <p><?php echo e($errors->first('role')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="avatar" class="col-sm-2 control-label">Avatar</label>
                <div class="col-sm-10">
                    <input type="file" id="avatar" name="avatar" class="form-control<?php echo e($errors->has('avatar') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('avatar')); ?>">
                    <?php if($errors->has('avatar')): ?>
                        <span class="invalid-feedback">
                            <p><?php echo e($errors->first('avatar')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-group row">
                <label for="showgambar" class="col-sm-2 control-label">Preview</label>
                <div class="col-sm-10">
                    <img src="<?php echo e(asset('img/no-picture.jpg')); ?>" id="showgambar" alt=" " height="100">
                </div>
            </div>
        </div>
        <div class="card-footer">
            <button type="submit" class="btn btn-success float-right"><i class="fa fa-save"></i> Simpan</button>
            <button type="button" class="btn btn-default" onclick="history.go(-1)" id="batal">Batal</button>
        </div>
    </div>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_exhibition\resources\views/admin/user_add.blade.php ENDPATH**/ ?>