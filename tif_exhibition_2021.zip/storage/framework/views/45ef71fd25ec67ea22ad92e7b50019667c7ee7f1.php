<?php $__env->startSection('content'); ?>
<section class="content col">
    <div class="row">
        <div class="col-lg-3 col-6">
            <div class="small-box bg-info">
                <div class="inner">
                    <h3><?php echo e($data['product_num']); ?></h3>
    
                    <p>Product</p>
                </div>
                <div class="icon">
                    <i class="icofont-cubes"></i>
                </div>
                <a href="<?php echo e(url('admin/product')); ?>" class="small-box-footer">Goto Product <i class="icofont-circled-right"></i></a>
            </div>
        </div>
        
        
        
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin._admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1011496/public_html/_exhibition/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>