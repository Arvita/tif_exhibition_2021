<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title><?php echo e(env('APP_NAME')); ?></title>
    <meta content="<?php echo e(env('APP_DESC')); ?>" name="description">
    <meta content="tif, exhibition, jti, polije" name="keywords">
    <meta property="og:title" content="<?php echo e(env('APP_NAME')); ?>">
	<meta property="og:description" content="<?php echo e(env('APP_DESC')); ?>">
	<meta property="og:image" content="<?php echo e(asset('img/favicon.png')); ?>">
	<meta property="og:url" content="<?php echo e(env('APP_URL')); ?>">

    <!-- Favicons -->
    <link href="<?php echo e(asset('img/favicon.png')); ?>" rel="icon">
    <link href="<?php echo e(asset('img/apple-touch-icon.png')); ?>" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Krub:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/icofont/icofont.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/venobox/venobox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/aos/aos.css')); ?>" rel="stylesheet">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

    <!-- Template Main CSS File -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">

    <!-- =======================================================
    * Template Name: Bikin - v2.2.0
    * Template URL: https://bootstrapmade.com/bikin-free-simple-landing-page-template/
    * Author: BootstrapMade.com
    * License: https://bootstrapmade.com/license/
    ======================================================== -->
</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="fixed-top">
        <div class="container d-flex align-items-center">

            
            <!-- Uncomment below if you prefer to use an image logo -->
            <a href="<?php echo e(url('/')); ?>" class="logo mr-auto"><img src="<?php echo e(asset('img/navbar-brand.svg')); ?>" alt="" class="img-fluid"></a>

            <nav class="nav-menu d-none d-lg-block">
                <ul>
                    <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li class="drop-down"><a href="">Visitor</a>
                        <ul>
                            <li><a href="#">Buku tamu</a></li>
                            <li><a href="#">Visitor Statistik</a></li>
                        </ul>
                    </li>

                </ul>
            </nav><!-- .nav-menu -->

            <a href="https://www.instagram.com/produktif_polije" target="_blank" class="get-started-btn scrollto"><i class="icofont-instagram"></i> Follow Instagram</a>

        </div>
    </header><!-- End Header -->

    <main id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer">

        <div class="footer-top">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3 col-md-6 footer-contact">
                        <h3><img src="<?php echo e(asset('img/polije-jti.svg')); ?>" alt="<?php echo e(env('APP_NAME')); ?>" class="img-fluid"></h3>
                        <p>
                            Gedung Jurusan Teknologi Informasi<br>
                            Politeknik Negeri Jember<br>
                            Jl. Mastrip PO.BOX 164 Jember, <br>Jawa Timur 68101 Indonesia<br><br>
                            <strong>Phone:</strong> (+62) 331-333532<br>
                            <strong>Email:</strong> jti1@polije.ac.id<br>
                        </p>
                    </div>

                    <div class="col-lg-1 col-md-6 footer-links"></div>

                    <div class="col-lg-4 col-md-6 footer-links">
                        <h4><i class="icofont-link"></i> Useful Links</h4>
                        <ul>
                            <li><i class="bx bx-chevron-right"></i> <a href="https://www.polije.ac.id">Polije</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="http://jti.polije.ac.id">JTI Polije</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="https://www.instagram.com/bempolije">BEM Polije</a></li>
                            <li><i class="bx bx-chevron-right"></i> <a href="http://jti.polije.ac.id/hmjti">HMJTI Polije</a></li>
                        </ul>
                    </div>

                    <div class="col-lg-4 col-md-6 footer-newsletter">
                        <h4><i class="icofont-globe"></i> Visitor Counter</h4>
                        <table class="table">
                        <tr><th width="35%"><i class="icofont-numbered"></i> Total</th><td width="2%">:</td><td><?php echo e(visits('App\Model\Product')->count()); ?> kunjungan</td></tr>
                        <tr><th><i class="icofont-calendar"></i> Hari Ini</th><td>:</td><td><?php echo e(visits('App\Model\Product')->period('day')->count()); ?> kunjungan</td></tr>
                        <tr><th><i class="icofont-calendar"></i> Minggu Ini</th><td>:</td><td><?php echo e(visits('App\Model\Product')->period('week')->count()); ?> kunjungan</td></tr>
                        <tr><th><i class="icofont-calendar"></i> Bulan Ini</th><td>:</td><td><?php echo e(visits('App\Model\Product')->period('month')->count()); ?> kunjungan</td></tr>
                        </table>
                    </div>

                </div>
            </div>
        </div>

        <div class="container d-md-flex py-4">

            <div class="mr-md-auto text-center text-md-left">
                <div class="copyright">
                    &copy; Copyright <strong><span>Produk TIF 2021</span></strong>. All Rights Reserved
                </div>
                <div class="credits">
                    <!-- All the links in the footer should remain intact. -->
                    <!-- You can delete the links only if you purchased the pro version. -->
                    <!-- Licensing information: https://bootstrapmade.com/license/ -->
                    <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/bikin-free-simple-landing-page-template/ -->
                    
                </div>
            </div>
            <div class="social-links text-center text-md-right pt-3 pt-md-0">
                <a href="http://www.instagram.com/produktif_polije" class="instagram"><i class="bx bxl-instagram"></i></a>
            </div>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>
    <div id="preloader"></div>

    <!-- Vendor JS Files -->
    <script src="<?php echo e(asset('vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/jquery.easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/php-email-form/validate.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/owl.carousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/isotope-layout/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/venobox/venobox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/aos/aos.js')); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo e(asset('plugins/select2/js/select2.full.min.js')); ?>"></script>

    <!-- Template Main JS File -->
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>

</body>
</html>

<?php /**PATH D:\Projek\produk-tif\resources\views/layouts/main.blade.php ENDPATH**/ ?>