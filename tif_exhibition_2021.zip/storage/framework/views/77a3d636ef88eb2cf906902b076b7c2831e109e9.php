<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible">
        <a href="#" class="close text-decoration-none" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('info')): ?>
    <div class="alert alert-info alert-dismissible">
        <a href="#" class="close text-decoration-none" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible">
        <a href="#" class="close text-decoration-none" data-dismiss="alert" aria-label="close">&times;</a>
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?><?php /**PATH /home/u1011496/public_html/_exhibition/resources/views/layouts/_alert.blade.php ENDPATH**/ ?>