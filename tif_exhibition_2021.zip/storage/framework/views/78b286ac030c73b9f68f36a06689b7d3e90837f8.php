<!-- Content Header (Page header) -->
<div class="content-header bg-white border-bottom py-2 mb-2">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <h5 class="m-0 font-weight-bold text-dark"><?php echo e(@$data['title']); ?> <span class="small text-muted"><?php echo e(@$data['subtitle']); ?></span></h5>
            </div><!-- /.col -->
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right small">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('/admin')); ?>">Beranda</a></li>
                    <?php if($data['npage'] !== 0): ?>
                        <li class='breadcrumb-item active'><?php echo e(@$data['title']); ?></li>
                    <?php endif; ?>
                </ol>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\_exhibition\resources\views/layouts/admin/_breadcrumb.blade.php ENDPATH**/ ?>