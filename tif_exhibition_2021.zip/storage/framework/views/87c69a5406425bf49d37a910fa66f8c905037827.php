<?php $__env->startSection('content'); ?>
<div class="container" style="min-height: 80vh; padding-top: 150px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header text-center" style="background: #f6f7ff"><?php echo e(__('Login')); ?></div>

                <div class="card-body">
                    <div class="row justify-content-center py-5">
                        <div class="col-lg-8">
                            <a href="<?php echo e(url('google')); ?>" class="btn btn-outline-dark btn-block">
                                <img src="<?php echo e(url(asset('img/google.svg'))); ?>" alt=" " height="20"> <span class="small font-weight-bold">Login with Google</span>
                            </a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_exhibition\resources\views/auth/login.blade.php ENDPATH**/ ?>