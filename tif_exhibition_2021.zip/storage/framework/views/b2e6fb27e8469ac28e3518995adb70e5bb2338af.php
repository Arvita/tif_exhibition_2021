<?php $__env->startSection('content'); ?>
<section id="breadcrumbs" class="breadcrumbs">
    <div class="container">

        <ol>
            <li><a href="index.html">Home</a></li>
            <li><?php echo e($product->title); ?></li>
        </ol>

    </div>
</section>

<section id="portfolio-details" class="portfolio-details">
    <div class="container" data-aos="fade-up">

        <div class="row">
            <div class="col-lg-8">
                <h3 class="font-weight-bold"><?php echo e($product->title); ?></h3>
                <div class="owl-carousel portfolio-details-carousel mb-5">
                    <img src="<?php echo e(asset('img/portfolio/portfolio-details-1.jpg')); ?>" class="img-fluid" alt="">
                    <img src="<?php echo e(asset('img/portfolio/portfolio-details-2.jpg')); ?>" class="img-fluid" alt="">
                    <img src="<?php echo e(asset('img/portfolio/portfolio-details-3.jpg')); ?>" class="img-fluid" alt="">
                </div>
                <p><?php echo e($product->description); ?></p>
                <iframe width="100%" height="400" src="https://www.youtube.com/embed/ho4vAfTRnNo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="mt-5"></iframe>
            </div>

            <div class="col-lg-4 portfolio-info">
                <h3>Product Informations</h3>
                <ul>
                    <li><strong>Platform</strong>: <?php echo e($product->platform); ?></li>
                    <li><strong>Category</strong>: <?php echo e($product->category); ?></li>
                    <li><strong>Group Name</strong>: <?php echo e($product->group_name); ?></li>
                    <li><strong>Group Leader</strong>: <?php echo e($product->group_leader); ?> (<?php echo e($product->group_leader_nim); ?>)</li>
                    <li><strong>Group Member</strong>: <?php echo e($product->group_member); ?></li>
                    <li><strong>Semester / Golongan</strong>: <?php echo e($product->semester); ?> / <?php echo e($product->group_class); ?></li>
                </ul>
                <ul>
                    <li><a href="<?php echo e('https://api.whatsapp.com/send?phone='.$product->group_phone); ?>" class="btn btn-success btn-lg btn-block" target="_blank"><i class="icofont-whatsapp"></i> Hubungi Pengembang</a></li>
                    <li><a href="<?php echo e('mailto:'.$product->group_email); ?>" class="btn btn-primary btn-lg btn-block" target="_blank"><i class="icofont-envelope"></i> Email Pengembang</a></li>
                    <?php if($product->link_web): ?>
                        <li><a href="<?php echo e($product->link_web); ?>" class="btn btn-danger btn-lg btn-block" target="_blank"><i class="icofont-globe"></i> Lihat Website</a></li>
                    <?php endif; ?>
                    <?php if($product->link_mobile): ?>
                        <li><a href="<?php echo e($product->link_mobile); ?>" class="btn btn-dark btn-lg btn-block" target="_blank"><i class="icofont-brand-android-robot"></i> Download App</a></li>
                    <?php endif; ?>
                    <?php if($product->link_desktop): ?>
                        <li><a href="<?php echo e($product->link_desktop); ?>" class="btn btn-secondary btn-lg btn-block" target="_blank"><i class="icofont-brand-windows"></i> Download Desktop App</a></li>
                    <?php endif; ?>
                </ul>
                <h3 class="text-center mt-5">Vote produk ini dengan Like <i class="icofont-heart text-danger"></i></h3>
                <iframe id="instagram-embed-0" class="instagram-media instagram-media-rendered" style="background: white none repeat scroll 0% 0%; max-width: 540px; width: calc(100% - 2px); border-radius: 3px; border: 1px solid #dbdbdb; box-shadow: none; display: block; margin: 0px 0px 12px; min-width: 326px; padding: 0px;" src="<?php echo e($product->link_ig_poster); ?>embed/captioned/" height="1159" frameborder="0" scrolling="no" allowfullscreen="allowfullscreen" data-instgrm-payload-id="instagram-media-payload-0"></iframe>
                <script async="" src="//www.instagram.com/embed.js"></script>
            </div>

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek\produk-tif\resources\views/product.blade.php ENDPATH**/ ?>