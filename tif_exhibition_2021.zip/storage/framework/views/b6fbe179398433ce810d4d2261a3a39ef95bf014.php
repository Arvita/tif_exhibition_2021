<?php $__env->startSection('content'); ?>
<section id="sosmed" class="sosmed">
    <div class="container justify-content-center filter" data-aos="fade-up">
        <h2>Follow kami di <i class="icofont-instagram instagram p-1"></i> Instagram (<a href="https://www.instagram.com/produktif_polije" target="_blank" class="text-light">&#64;produktif_polije</a>) dan Vote Produk Pameran dengan memberi Like <i class="icofont-heart text-danger"></i></h2>
    </div>
</section>

<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">

    <div class="container justify-content-center filter" data-aos="fade-up">
        <h2 class="mb-3 text-center">Pilih platform dan masukkan kategori pencarian yang akan anda lihat</h2>
        <form action="#hero" method="get" class="border-0">
            <div class="row">
                <div class="col-lg-6 col-md-12 filter">
                    <div class="input-group input-group-sm">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Platform</span>
                          </div>
                        <select id="platform" name="platform" class="form-control select2nosearch">
                            <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($platform->platform); ?>"<?php echo e((Request::input('platform') == $platform->platform) ? ' selected' : ''); ?>><?php echo e($platform->platform); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 filter">
                    <div class="input-group input-group-sm">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Category</span>
                        </div>
                        <select id="category" name="category" class="form-control select2">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"<?php echo e((Request::input('category') == $category->id) ? ' selected' : ''); ?>><?php echo e($category->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-12 filter mt-3">
                    <div class="input-group input-group-lg">
                        <input id="search" name="search" type="text" class="form-control" value="<?php echo e((Request::input('search') != null) ? Request::input('search') : old('search')); ?>" required>
                        <span class="input-group-append">
                        <button type="submit" class="btn btn-primary btn-flat"><i class="icofont-ui-search"></i> Cari</button>
                        </span>
                    </div>
                </div>
            </div>
        </form>
    </div>

</section><!-- End Hero -->

<section id="products" class="products">
    <div class="container" data-aos="fade-up">

        <div class="section-title">
            <h2 class="m-0">Produk Pameran Mahasiswa</h2>
        </div>

        <div class="row">
            <?php if(count($products) > 0): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-4" data-aos="fade-up" data-aos-delay="100">
                    <div class="icon-box p-0">
                        <img src="<?php echo e(($product->featured_picture != null) ? url(asset('img/products/'.$product->featured_picture)) : 'https://placehold.it/400x200'); ?>" alt=" " class="img-fluid">
                        <div class="row">
                            <div class="col-lg-12 px-5 pt-5">
                                <h4 class="title"><a href="<?php echo e(url('product/'.$product->id.'/'.Str::slug($product->title, '-'))); ?>"><?php echo e($product->title); ?></a></h4>
                                <p class="description"><?php echo Str::limit($product->description, 100); ?></p>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 px-5 py-3">
                                <p><i class="icofont-users"></i> <?php echo e($product->group_leader); ?></p>
                                <p><i class="icofont-tags"></i> <?php echo e($product->platform); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-lg-12">
                    <div class="alert alert-primary text-center" role="alert">
                        <i class="icofont-warning h1"></i> <h3>Data yang anda cari tidak ditemukan!</h3>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <div class="row justify-content-center mt-5">
            <?php echo $products->render(); ?>

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\_exhibition\resources\views/home.blade.php ENDPATH**/ ?>