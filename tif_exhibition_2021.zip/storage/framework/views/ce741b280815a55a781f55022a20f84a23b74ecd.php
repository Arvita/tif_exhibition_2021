<?php $__env->startSection('content'); ?>
<section id="sosmed" class="sosmed">
    <div class="container justify-content-center filter" data-aos="fade-up">
        <h1>Follow kami di <i class="icofont-instagram instagram p-1"></i> Instagram dan Vote Produk Pameran dengan memberi Like <i class="icofont-heart text-danger"></i></h1>
    </div>
</section>

<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">

    <div class="container justify-content-center filter" data-aos="fade-up">
        <h2 class="mb-3 text-center">Pilih platform dan masukkan kategori pencarian yang akan anda lihat</h2>
        <form action="" method="get" class="border-0">
            <div class="row">
                <div class="col-lg-6 col-md-12 filter">
                    <div class="input-group input-group-sm">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Platform</span>
                          </div>
                        <select id="platform" name="platform" class="form-control select2nosearch">
                            <?php $__currentLoopData = $platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($platform->platform); ?>"><?php echo e($platform->platform); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 filter">
                    <div class="input-group input-group-sm">
                        <div class="input-group-prepend">
                            <span class="input-group-text">Category</span>
                        </div>
                        <select id="category" name="category" class="form-control select2">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->category); ?>"><?php echo e($category->category); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-lg-12 filter mt-3">
                    <div class="input-group input-group-lg">
                        <input id="search" name="search" type="text" class="form-control" value="<?php echo e(old('search')); ?>" required>
                        <span class="input-group-append">
                        <button type="submit" class="btn btn-primary btn-flat"><i class="icofont-ui-search"></i> Cari</button>
                        </span>
                    </div>
                </div>
            </div>
        </form>
    </div>

</section><!-- End Hero -->

<section id="products" class="products">
    <div class="container" data-aos="fade-up">

        <div class="section-title">
            <h2>Produk Pameran Mahasiswa</h2>
            <p>&nbsp;</p>
        </div>

        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="fade-up" data-aos-delay="100">
                <div class="icon-box p-0">
                    <img src="<?php echo e(($product->featured_picture != null) ? asset('img/products/'.$product->featured_picture) : 'https://placehold.it/400x200'); ?>" alt=" " class="img-fluid">
                    <div class="row">
                        <div class="col-lg-12 px-5 pt-5">
                            <h4 class="title"><a href="<?php echo e(url('product/'.$product->id.'/'.Str::slug($product->title, '-'))); ?>"><?php echo e($product->title); ?></a></h4>
                            <p class="description"><?php echo e(Str::limit($product->description, 100)); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 px-5 py-3">
                            <p><i class="icofont-users"></i> <?php echo e($product->group_leader); ?></p>
                            <p><i class="icofont-tags"></i> <?php echo e($product->platform); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row justify-content-center">
            <?php echo $products->render(); ?>

        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projek\produk-tif\resources\views/home.blade.php ENDPATH**/ ?>