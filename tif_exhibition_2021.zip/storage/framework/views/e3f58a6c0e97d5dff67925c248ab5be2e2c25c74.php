<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e(env('APP_DESC')); ?>">
    <meta name="author" content="<?php echo e(env('WEB_AUTHOR')); ?>">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($data['title']); ?> | <?php echo e(env('APP_NAME')); ?></title>
    <link rel="icon" href="<?php echo e(url(asset('img\favicon.png'))); ?>" sizes="32x32" />
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/fontawesome-free/css/all.min.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/Ionicons/css/ionicons.min.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/simple-line-icons/css/simple-line-icons.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('vendor/icofont/icofont.min.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('dist/css/adminlte.min.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/overlayScrollbars/css/OverlayScrollbars.min.css'))); ?>">
    
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/datatables-bs4/css/dataTables.bootstrap4.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/datatables-responsive/css/responsive.bootstrap4.min.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/select2/css/select2.min.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/dropzone/dropzone.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('plugins/summernote/summernote-bs4.css'))); ?>">
    
    <link rel="stylesheet" href="<?php echo e(url(asset('css/custom.css'))); ?>" />
    
    <script src="<?php echo e(url(asset('plugins/jquery/jquery.min.js'))); ?>"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item d-none d-sm-inline-block">
                    <a href="<?php echo e(url('/')); ?>" class="nav-link">Halaman Utama</a>
                </li>
            </ul>
        </nav>
        
        
        <?php echo $__env->make('layouts.admin._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        
        <div class="content-wrapper">
            <?php echo $__env->make('layouts.admin._breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="content">
                <?php echo $__env->make('layouts._alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        

        <footer class="main-footer small">
            <strong>Copyright &copy; 2021 <a href="<?php echo e(env('APP_URL')); ?>" class="text-dark"><?php echo e(env('APP_NAME')); ?></a>.</strong>
            <div class="float-right d-none d-sm-inline-block">
                Develop By <a href="https://djuliar.github.com" target="_blank" class="text-dark">Djuliar</a> | <b>Version</b> 1.0.0 
            </div>
        </footer>
    </div>
    

    
    <script src="<?php echo e(url(asset('plugins/jquery-ui/jquery-ui.min.js'))); ?>"></script>
    
    <script>
    $.widget.bridge('uibutton', $.ui.button)
    </script>
    
    <script src="<?php echo e(url(asset('plugins/bootstrap/js/bootstrap.bundle.min.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('plugins/datatables/jquery.dataTables.min.js'))); ?>"></script>
    <script src="<?php echo e(url(asset('plugins/datatables-bs4/js/dataTables.bootstrap4.min.js'))); ?>"></script>
    <script src="<?php echo e(url(asset('plugins/datatables-responsive/js/dataTables.responsive.min.js'))); ?>"></script>
    <script src="<?php echo e(url(asset('plugins/datatables-responsive/js/responsive.bootstrap4.min.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('plugins/select2/js/select2.full.min.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('plugins/dropzone/dropzone.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('plugins/summernote/summernote-bs4.min.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('dist/js/adminlte.js'))); ?>"></script>
    
    <script src="<?php echo e(url(asset('js/admin.js'))); ?>"></script>
</body>
</html><?php /**PATH /home/u1011496/public_html/_exhibition/resources/views/layouts/admin/_admin.blade.php ENDPATH**/ ?>